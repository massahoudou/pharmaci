<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211221094602 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE pub ADD adresse VARCHAR(255) NOT NULL, ADD site VARCHAR(255) NOT NULL, ADD localisation LONGTEXT NOT NULL, ADD telephone1 INT NOT NULL, ADD telephone2 INT DEFAULT NULL');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE pub DROP adresse, DROP site, DROP localisation, DROP telephone1, DROP telephone2');
    }
}
